#!/usr/bin/env sh
# generated from dynamic_reconfigure/cmake/setup_custom_pythonpath.sh.in

PYTHONPATH=/home/itcast/Desktop/heima_ws/src/zxcar_nav/cmake-build-debug/devel/lib/python2.7/dist-packages:$PYTHONPATH
exec /usr/bin/python2 "$@"
