#!/usr/bin/env sh
# generated from dynamic_reconfigure/cmake/setup_custom_pythonpath.sh.in

PYTHONPATH=/home/itcast/Documents/itheima_ws/src/imu_filter_madgwick/cmake-build-debug/devel/lib/python2.7/dist-packages:$PYTHONPATH
exec /usr/bin/python2 "$@"
