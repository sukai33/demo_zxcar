# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "${prefix}/include".split(';') if "${prefix}/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;rospy;tf;nav_msgs;geometry_msgs;sensor_msgs;std_msgs".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lheimarobot".split(';') if "-lheimarobot" != "" else []
PROJECT_NAME = "zxcar"
PROJECT_SPACE_DIR = "/usr/local"
PROJECT_VERSION = "0.0.0"
